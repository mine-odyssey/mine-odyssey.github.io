@echo off
setlocal
title Mine Odyssey - Minecraft Connection
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Connect Mine Odyssey.ps1"
set "MINE_ODYSSEY_EXIT=%ERRORLEVEL%"
echo.
echo The connection helper has stopped. Keep this window open while playing.
pause
exit /b %MINE_ODYSSEY_EXIT%
