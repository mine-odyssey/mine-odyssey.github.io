#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Test-MineOdysseyBinary {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -eq '2493dbc168923bb3e59e5e7716f71deced92992eea9acd6e9d74f84ac7751343'
}

function Get-MineOdysseyBinary {
    param([string]$CacheDirectory)
    $null = New-Item -ItemType Directory -Path $CacheDirectory -Force
    $binary = Join-Path $CacheDirectory 'cloudflared-2026.10.7-amd64.exe'
    if (Test-MineOdysseyBinary $binary) { return $binary }
    $download = $binary + '.' + $PID + '.part'
    try {
        for ($attempt = 1; $attempt -le 3; $attempt++) {
            try {
                Write-Host 'Downloading the official Cloudflare connection helper...'
                Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/cloudflare/cloudflared/releases/download/2026.10.7/cloudflared-windows-amd64.exe' -OutFile $download -TimeoutSec 180
                break
            } catch {
                if ($attempt -eq 3) { throw }
                Start-Sleep -Seconds 2
            }
        }
        if (-not (Test-MineOdysseyBinary $download)) {
            throw 'Download integrity check failed. The downloaded file will not be run.'
        }
        Move-Item -LiteralPath $download -Destination $binary -Force
        return $binary
    } finally {
        if (Test-Path -LiteralPath $download) { Remove-Item -LiteralPath $download -Force }
    }
}

function Assert-MineOdysseyPortFree {
    param([int]$Port = 25590)
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
    $listener.Server.ExclusiveAddressUse = $true
    try { $listener.Start() }
    catch { throw "Local port $Port is already in use. Close the other connection-helper window and retry." }
    finally { $listener.Stop() }
}

try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
        throw 'Use this helper on Windows 10/11 with a 64-bit Intel or AMD processor.'
    }
    $machineArchitecture = $env:PROCESSOR_ARCHITEW6432
    if (-not $machineArchitecture) { $machineArchitecture = $env:PROCESSOR_ARCHITECTURE }
    if ($machineArchitecture -ne 'AMD64') {
        throw 'This package supports Intel/AMD 64-bit Windows. ARM and 32-bit Windows are not supported by this package.'
    }
    if (-not $env:LOCALAPPDATA) { throw 'The Windows local application data directory is unavailable.' }
    Assert-MineOdysseyPortFree
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $cacheDirectory = Join-Path $env:LOCALAPPDATA 'MineOdyssey\connection-helper'
    $binary = Get-MineOdysseyBinary $cacheDirectory
    Write-Host ''
    Write-Host 'Mine Odyssey connection is starting.' -ForegroundColor Green
    Write-Host 'In Minecraft, connect to 127.0.0.1:25590.'
    Write-Host 'Keep this window open during the task. Closing it disconnects the game.'
    Write-Host ''
    & $binary access tcp --hostname bronze-reporting-brought-friendship.trycloudflare.com --url 127.0.0.1:25590
    if ($LASTEXITCODE -ne 0) { throw "The connection helper stopped (exit code $LASTEXITCODE)." }
    exit 0
} catch {
    Write-Host ('Connection failed: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Share this error message with the evaluation organizer.'
    exit 1
}
