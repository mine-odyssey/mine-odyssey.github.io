﻿Mine Odyssey — Windows 人工评测连接助手

适用于 Windows 10/11，Intel/AMD 64 位电脑。
评测入口：https://mine-odyssey.github.io/human-evaluation/native/

1. 在网页输入分配给你的访问码，绑定自己的 Minecraft Java 版游戏用户名。
   填游戏用户名，不是 Microsoft 邮箱。使用已有 Minecraft Java 版账号。
2. 右键本 ZIP，选择“全部解压缩”。保留 .bat 和 .ps1 在同一个文件夹。
3. 双击 Connect Mine Odyssey.bat。首次运行会下载连接组件，等窗口显示
   “Start Websocket listener” 后继续。评测期间保持这个窗口打开。
4. 从 https://prismlauncher.org/download/windows/ 安装 Prism Launcher，
   在 Prism 中登录自己的 Microsoft / Minecraft Java 账号。
5. 回到评测网页点击“准备下一项任务”，等待专用客户端包可下载。
   在 Prism 选择“添加实例 → 导入”，选择下载的 .mrpack 文件。
   让 Prism 安装这个实例需要的 Java 和模组；不要导入到已有的游戏实例。
6. 启动该实例，选择“多人游戏 → 直接连接”，输入 127.0.0.1:25590。
   游戏显示等待界面后，回网页点击“开始任务”。完成后在网页提交。

每项任务使用新下载的实例。练习不计入正式成绩；每项最多提交 3 次。
关闭连接窗口或断开游戏会结束当前尝试。

如果窗口提示端口被占用，请关闭此前打开的连接助手，再启动一次。
若 Windows 或单位策略拦截脚本，请把提示发给组织者，不要关闭安全软件。
首次下载失败时检查到 GitHub 的网络连接，重试即可；下载的组件经过 SHA-256 校验。
本包不需要管理员权限，不修改系统执行策略，不安装后台服务，也不收集账号密码。
Microsoft 账号仅登录到 Prism；请勿把密码发送给组织者。

连接组件：Cloudflare cloudflared 2026.10.7，官方 Windows x64 发布文件。
源地址：https://github.com/cloudflare/cloudflared/releases/tag/2026.10.7
连接使用临时隧道；长期连续连接的稳定性仍需实测。
Windows ARM、32 位系统及 Bedrock 版不适用本包。
